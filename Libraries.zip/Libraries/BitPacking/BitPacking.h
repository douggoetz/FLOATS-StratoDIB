/*
 *  BitPacking.h
 *  Bit packing functions to be used for telemetry
 *  packets for the Strateole 2 Project
 *  Author: Marika Schubert
 *  January 2019
 *  
 *  This library will allow devices on the Strateole project
 *	to  condense numeric values to binary representations
 *	This file does not format the telemtry packets, only
 *  return data to be passed to the XML_Writer_v3.h
 * 
 *  This code has the following dependency:
 *
 *	"Arduino.h"
 */
 
 #ifndef BITPACKING_H_
 #define BITPACKING_H_
  
uint32_t latLongFloat2Bin(float gpsFloat);
uint16_t tempFloat2Bin(float tempFloat);
uint8_t voltInt2Short(uint16_t voltInt);


 
 #endif