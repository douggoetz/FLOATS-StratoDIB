/*
 *  BitPacking.cpp
 *  Bit packing functions to be used for telemetry
 *  packets for the Strateole 2 Project
 *  Author: Marika Schubert
 *  January 2019
 *  
 *  This library will allow devices on the Strateole project
 *	to  condense numeric values to binary representations
 *	This file does not format the telemtry packets, only
 *  return data to be passed to the XML_Writer_v3.h
 * 
 *  This code has the following dependency:
 *
 *	"Arduino.h"
 *  "BitPacking.h"
 */
 
#include "Arduino.h"
#include "BitPacking.h"

// The latLong functions return uint32_t's as 24 bits is not a standard data type
// The uppermost byte will be ignored by the XML_Writer_v3
uint32_t latLongFloat2Bin(float gpsFloat){
    uint32_t ret = 0;
    if (gpsFloat < 0){
        ret |= 1 << 23;
        gpsFloat = (-1.0)*gpsFloat;
    }
    uint32_t gpsInt = int(gpsFloat*32768); // 2^15
    if (gpsInt > (1<<24)){
        ret |= 0xFF000000; // Bits in the upper byte to so err
    } else {
        ret |= gpsInt;
    }
    return ret;
    
}

uint16_t tempFloat2Bin(float tempFloat){
    uint16_t ret = 0;
    if (tempFloat < 0){
        ret |= (0x8000);
        tempFloat = (-1)*tempFloat;
    }
    uint16_t tempInt = int(tempFloat*256);
    if (tempInt > (0x8000)){
        ret = 0x8000;
    } else {
        ret |= tempInt;
    }
    return ret;
}

uint8_t voltInt2Short(uint16_t voltInt){
    uint8_t ret = 0;
    ret = voltInt >> 2;
    return ret;
    
}